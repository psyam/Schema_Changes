set nocount on
go
IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[claim_processed_main]') AND name = N'idx_claim_processed_main_valref')
DROP INDEX [idx_claim_processed_main_valref] ON [dbo].[claim_processed_main]
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[claim_processed_detail]') AND name = N'idx_claim_processed_detail')
DROP INDEX [idx_claim_processed_detail] ON [dbo].[claim_processed_detail]
GO
CREATE NONCLUSTERED INDEX [idx_claim_processed_main_valref]
ON [dbo].[claim_processed_main] ([value_ref] ASC, [claim_dt] ASC, [claim_month] ASC)
INCLUDE ([claim_id], [mbr_idn], [claim_processed_main_idn])
GO
CREATE NONCLUSTERED INDEX [idx_claim_processed_detail]
ON [dbo].[claim_processed_detail] ([prop_value] ASC, [claim_prop_type_idn] ASC)
INCLUDE ( [claim_id], [claim_processed_detail_idn])
GO
INSERT  INTO [versioning] ([Version_Number], [Version_Dt], [V_Comment], [crt_dt], [upd_dt], [user_idn])
VALUES  ('5.2_BCI_107', GETDATE(), 'Script for Index modification for DM ID Claim tables', GETDATE(), GETDATE(), 2)
PRINT 'Script with version_number 5.2_BCI_107 executed Successfully'