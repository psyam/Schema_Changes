set nocount on
go
INSERT INTO [code_sre_event_name] ([name],[entity_active],[crt_dt],[upd_dt],[user_idn],[is_default],[is_required],[source])VALUES('DM CAD','Y',getdate(),getdate(),2,'N','N','Manual')
INSERT INTO [code_sre_event_name] ([name],[entity_active],[crt_dt],[upd_dt],[user_idn],[is_default],[is_required],[source])VALUES('DM CAD Ruleset','Y',getdate(),getdate(),2,'N','N','Manual')
INSERT INTO [code_keyword] ([keyword_desc],[user_idn],[crt_dt],[upd_dt],[entity_active],[is_reserved],[is_default],[is_required],[note],[source],[keyword_cd]) VALUES('CAD',2,getdate(),getdate(),'Y','N','N','N',NULL,'Manual','CAD')
INSERT INTO [code_keyword] ([keyword_desc],[user_idn],[crt_dt],[upd_dt],[entity_active],[is_reserved],[is_default],[is_required],[note],[source],[keyword_cd]) VALUES('CAD - High Risk',2,getdate(),getdate(),'Y','N','N','N',NULL,'Manual','CADHR')
INSERT INTO [code_keyword] ([keyword_desc],[user_idn],[crt_dt],[upd_dt],[entity_active],[is_reserved],[is_default],[is_required],[note],[source],[keyword_cd]) VALUES('CAD - Low Risk',2,getdate(),getdate(),'Y','N','N','N',NULL,'Manual','CADLR')
GO
INSERT  INTO [versioning] ([Version_Number], [Version_Dt], [V_Comment], [crt_dt], [upd_dt], [user_idn])
VALUES  ('5.2_BCI_118', GETDATE(), 'Script for adding event names and Keyword for CAD program', GETDATE(), GETDATE(), 2)
PRINT 'Script with version_number 5.2_BCI_118 executed Successfully'
