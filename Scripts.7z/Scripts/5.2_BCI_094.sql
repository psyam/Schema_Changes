set nocount on
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[claim_processed_main]') AND name = N'idx_claim_processed_main')
DROP INDEX [idx_claim_processed_main] ON [dbo].[claim_processed_main]
GO
CREATE NONCLUSTERED INDEX [idx_claim_processed_main] ON [dbo].[claim_processed_main] 
([claim_dt] ASC, [claim_month] ASC)
INCLUDE ([claim_id],[mbr_idn],[value_ref])
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[claim_processed_detail]') AND name = N'idx_claim_processed_detail')
DROP INDEX [idx_claim_processed_detail] ON [dbo].[claim_processed_detail]
GO
CREATE NONCLUSTERED INDEX [idx_claim_processed_detail] 
ON [dbo].[claim_processed_detail] ([claim_prop_type_idn] ASC, [prop_value] ASC)
INCLUDE ([claim_id])
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[claim_processed_detail]') AND name = N'idx_claim_proc_dtl_claim_id')
DROP INDEX [idx_claim_proc_dtl_claim_id] ON [dbo].[claim_processed_detail]
GO
CREATE NONCLUSTERED INDEX [idx_claim_proc_dtl_claim_id]
ON [dbo].[claim_processed_detail] ([claim_id])
INCLUDE ([claim_prop_type_idn],[prop_value])
Go
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[claim_prop_type]') AND name = N'idx_claim_prop_type')
DROP INDEX [idx_claim_prop_type] ON [dbo].[claim_prop_type]
GO
CREATE INDEX [idx_claim_prop_type]
ON [claim_prop_type]([claim_prop_type])
INCLUDE (claim_prop_type_idn, prop_type_ref)
GO
INSERT  INTO [versioning] ([Version_Number], [Version_Dt], [V_Comment], [crt_dt], [upd_dt], [user_idn])
VALUES  ('5.2_BCI_094', GETDATE(), 'Script of Indexes created for the processed tables', GETDATE(), GETDATE(), 2)
PRINT 'Script with version_number 5.2_BCI_094 executed Successfully'