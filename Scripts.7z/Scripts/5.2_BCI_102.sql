set nocount on
go
INSERT INTO [code_sre_event_name] ([name],[entity_active],[crt_dt],[upd_dt],[user_idn],[is_default],[is_required],[source])VALUES('DM COPD','Y',getdate(),getdate(),2,'N','N','Manual')
INSERT INTO [code_sre_event_name] ([name],[entity_active],[crt_dt],[upd_dt],[user_idn],[is_default],[is_required],[source])VALUES('DM COPD Ruleset','Y',getdate(),getdate(),2,'N','N','Manual')
INSERT INTO [code_keyword] ([keyword_desc],[user_idn],[crt_dt],[upd_dt],[entity_active],[is_reserved],[is_default],[is_required],[note],[source],[keyword_cd]) VALUES('COPD',2,getdate(),getdate(),'Y','N','N','N',NULL,'Manual','COPD')
INSERT INTO [code_keyword] ([keyword_desc],[user_idn],[crt_dt],[upd_dt],[entity_active],[is_reserved],[is_default],[is_required],[note],[source],[keyword_cd]) VALUES('COPD - High Risk',2,getdate(),getdate(),'Y','N','N','N',NULL,'Manual','COPDHR')
INSERT INTO [code_keyword] ([keyword_desc],[user_idn],[crt_dt],[upd_dt],[entity_active],[is_reserved],[is_default],[is_required],[note],[source],[keyword_cd]) VALUES('COPD - Low Risk',2,getdate(),getdate(),'Y','N','N','N',NULL,'Manual','COPDLR')
GO
INSERT  INTO [versioning] ([Version_Number], [Version_Dt], [V_Comment], [crt_dt], [upd_dt], [user_idn])
VALUES  ('5.2_BCI_102', GETDATE(), 'Script for adding event names and Keyword for sentinel DMID', GETDATE(), GETDATE(), 2)
PRINT 'Script with version_number 5.2_BCI_102 executed Successfully'
