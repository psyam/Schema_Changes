set nocount on
go
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[claim_processed_main]') AND name = N'idx_claim_processed_main')
DROP INDEX [idx_claim_processed_main] ON [dbo].[claim_processed_main]
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[claim_processed_detail]') AND name = N'idx_claim_proc_dtl_claim_id')
DROP INDEX [idx_claim_proc_dtl_claim_id] ON [dbo].[claim_processed_detail]
GO
IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[sre_identry]') AND name = N'idx_sre_identry_mbr_idn')
DROP INDEX [idx_sre_identry_mbr_idn] ON [dbo].[sre_identry]
GO
IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[sre_identry]') AND name = N'idx_sre_identry_mbridn')
DROP INDEX [idx_sre_identry_mbridn] ON [dbo].[sre_identry]
GO
CREATE NONCLUSTERED INDEX [idx_sre_identry_mbridn]
ON [dbo].[sre_identry] ([mbr_idn] ASC, [sre_idpool_idn] ASC)
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[sre_refvalue]') AND name = N'idx_sre_refvalue_entact')
DROP INDEX [idx_sre_refvalue_entact] ON [dbo].[sre_refvalue]  
Go
CREATE NONCLUSTERED INDEX [idx_sre_refvalue_entact] 
ON [dbo].[sre_refvalue] (entity_Active )
INCLUDE (SRE_REFROW_ID ,VALUE,SRE_REFCOLUMN_IDN,SRE_REFTABLE_IDN)  
GO
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[sre_refvalue]') AND name = N'idx_sre_refvalue_reftable_idn')
DROP INDEX [idx_sre_refvalue_reftable_idn] ON [dbo].[sre_refvalue] 
GO
CREATE NONCLUSTERED INDEX idx_sre_refvalue_reftable_idn 
ON [dbo].[sre_refvalue] ([sre_reftable_idn],[sre_refcolumn_idn],[entity_active]) 
INCLUDE ([value])
GO
INSERT  INTO [versioning] ([Version_Number], [Version_Dt], [V_Comment], [crt_dt], [upd_dt], [user_idn])
VALUES  ('5.2_BCI_106', GETDATE(), 'Script for Index modification for DM ID', GETDATE(), GETDATE(), 2)
PRINT 'Script with version_number 5.2_BCI_106 executed Successfully'