set nocount on
GO
INSERT INTO [code_sre_event_name] ([name],[entity_active],[crt_dt],[upd_dt],[user_idn],[is_default],[is_required],[source])VALUES('DM HeartFailure','Y',getdate(),getdate(),2,'N','N','Manual')
INSERT INTO [code_sre_event_name] ([name],[entity_active],[crt_dt],[upd_dt],[user_idn],[is_default],[is_required],[source])VALUES('DM HeartFailure Ruleset','Y',getdate(),getdate(),2,'N','N','Manual')
INSERT INTO [code_keyword] ([keyword_desc],[user_idn],[crt_dt],[upd_dt],[entity_active],[is_reserved],[is_default],[is_required],[note],[source],[keyword_cd]) VALUES('Heart Failure',2,getdate(),getdate(),'Y','N','N','N',NULL,'Manual','HF')
INSERT INTO [code_keyword] ([keyword_desc],[user_idn],[crt_dt],[upd_dt],[entity_active],[is_reserved],[is_default],[is_required],[note],[source],[keyword_cd]) VALUES('Heart Failure - High Risk',2,getdate(),getdate(),'Y','N','N','N',NULL,'Manual','HFHR')
INSERT INTO [code_keyword] ([keyword_desc],[user_idn],[crt_dt],[upd_dt],[entity_active],[is_reserved],[is_default],[is_required],[note],[source],[keyword_cd]) VALUES('Heart Failure - Low Risk',2,getdate(),getdate(),'Y','N','N','N',NULL,'Manual','HFLR')
GO
INSERT  INTO [versioning] ([Version_Number], [Version_Dt], [V_Comment], [crt_dt], [upd_dt], [user_idn])
VALUES  ('5.2_BCI_097', GETDATE(), 'Script to creating events and keywords for Heart Failure Program', GETDATE(), GETDATE(), 2)
PRINT 'Script with version_number 5.2_BCI_097 executed Successfully'
