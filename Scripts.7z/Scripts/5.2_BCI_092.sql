set nocount on
go
if  exists (select * from sys.objects where object_id = object_id(N'[dbo].[claim_header_stg]') and type in (N'u'))
drop table [dbo].[claim_header_stg]
go
CREATE TABLE [dbo].[claim_header_stg](
	[DT_CLAIM_RECEIVED] [datetime] NULL,
	[CLAIM_MONTH] [int] NULL,
	[CLAIM_ID] [varchar](25) NULL,
	[ENROLL_ID] [varchar](49) NULL,
	[MBR_IDN] [numeric](18, 0) NULL,
	[ADMIT_TYPE_CD] [varchar](25) NULL,
	[SERVICING_PRV_ID] [varchar](16) NULL,
	[SERVICING_PRV_SPLTY_CD] [varchar](4) NULL,
	[SERVICING_PRV_PAR] [varchar](1) NULL,
	[ATTENDING_PRV_ID] [varchar](25) NULL,
	[BILLING_PRV_ID] [varchar](16) NULL,
	[PLACE_OF_SVC_CD] [varchar](25) NULL,
	[TYPE_OF_SVC_CD] [varchar](25) NULL,
	[TYPE_OF_BILL] [char](3) NULL,
	[GROUP_NO] [char](8) NULL,
	[CLAIM_TYPE] [varchar](3) NULL,
	[ALLOWED_AMT_TOTAL] [numeric](18, 2) NULL,
	[BILLED_AMT_TOTAL] [numeric](18, 2) NULL,
	[PAID_AMT_TOTAL] [numeric](18, 2) NULL,
	[DT_ADMITTED] [datetime] NULL,
	[DT_DISCHARGED] [datetime] NULL,
	[DT_OF_SVC_BEGIN] [datetime] NULL,
	[DT_OF_SVC_END] [datetime] NULL,
	[DRG_CODE] [int] NULL,
	[PRIMARY_DIAG_CODE] [varchar](20) NULL,
	[ICD9_DIAG_CODE_1] [varchar](15) NULL,
	[ICD9_DIAG_CODE_2] [varchar](255) NULL,
	[ICD9_DIAG_CODE_3] [varchar](255) NULL,
	[ICD9_DIAG_CODE_4] [varchar](20) NULL,
	[DT_PAID] [datetime] NULL
)
GO
if  exists (select * from sys.objects where object_id = object_id(N'[dbo].[claim_line_stg]') and type in (N'u'))
drop table [dbo].[claim_line_stg]
Go
CREATE TABLE [dbo].[claim_line_stg](
	[mbr_idn] [numeric](18, 0) NULL,
	[claim_id] [varchar](60) NULL,
	[claim_suffix] [varchar](50) NULL,
	[line_number] [int] NULL,
	[auth_id] [varchar](15) NULL,
	[proc_cd] [varchar](50) NULL,
	[proc_desc] [varchar](max) NULL,
	[revenue_code] [varchar](50) NULL,
	[cpt_hcpcs_modifier] [varchar](25) NULL,
	[billed_hcpcs_modifier1] [varchar](25) NULL,
	[billed_hcpcs_modifier2] [varchar](25) NULL,
	[billed_hcpcs_modifier3] [varchar](25) NULL,
	[allowed_amt_line_item] [numeric](18, 2) NULL,
	[billed_amt_line_item] [numeric](18, 2) NULL,
	[cob_paid_amt_line_item] [numeric](18, 2) NULL,
	[coinsurance_amt_line_item] [numeric](18, 2) NULL,
	[copay_amt_line_item] [numeric](18, 2) NULL,
	[deductible_amt_line_item] [numeric](18, 2) NULL,
	[not_covered_amt_line_item] [numeric](18, 2) NULL,
	[paid_amt_line_item] [numeric](18, 2) NULL,
	[dt_of_svc_beg_line_item] [datetime] NULL,
	[dt_of_svc_end_line_item] [datetime] NULL,
	[units_per_days_allowed] [int] NULL,
	[units_per_days_billed] [int] NULL,
	[claim_status_code_line_item] [varchar](15) NULL,
	[anesthesia_start_time] [varchar](3) NULL,
	[anesthesia_end_time] [varchar](3) NULL,
	[anesthesia_total_time] [varchar](3) NULL,
	[err_code] [varchar](15) NULL,
	[err_code_text] [varchar](100) NULL,
    [member_full_name] [varchar](100) NULL,
    [birth_dt] [datetime],
    [gender] [varchar](50) NULL,
    [group_name] [varchar](100) NULL,
    [group_effective_date] [datetime],
    [group_term_date] [datetime],
    [servicing_provider_first_name] [varchar](50) NULL,
    [servicing_provider_last_name] [varchar](150) NULL,
    [servicing_provider_prov_type_cd] [varchar](50) NULL,
    [attending_provider_first_name] [varchar](100) NULL,
    [attending_provider_last_name] [varchar](150) NULL,
    [attending_provider_prov_type_cd] [varchar](50) NULL,
    [attending_provider_specialty_cd] [varchar](50) NULL,
    [billing_provider_first_name] [varchar](100) NULL,
    [billing_provider_last_name] [varchar](100) NULL
)
GO

if  exists (select * from sys.objects where object_id = object_id(N'[dbo].[pharmacy_claim_stg]') and type in (N'u'))
drop table [dbo].[pharmacy_claim_stg]
Go
CREATE TABLE [dbo].[pharmacy_claim_stg](
	[enroll_id] [varchar](50) NULL,
	[claim_id] [varchar](50) NULL,
	[mbr_idn] [numeric](18, 0) NULL,
	[prescriber_prv_idn] [varchar](80) NULL,
	[prescriber_name] [varchar](100) NULL,
	[date_filled] [datetime] NULL,
	[ndc] [varchar](50) NULL,
	[pharmacy_prv_idn] [numeric](18, 0) NULL,
	[prv_dea_num] [varchar](50) NULL,
	[pharmacy_nabp_num] [varchar](50) NULL,
	[dispense_status_code] [varchar](2) NULL,
	[qty_dispensed] [numeric](18, 0) NULL,
	[days_supply] [int] NULL,
	[rx_class] [varchar](8) NULL,
	[drug_name] [varchar](30) NULL,
	[refill] [tinyint] NULL,
	[route] [varchar](20) NULL,
	[amount_billed] [numeric](30, 2) NULL,
	[amount_allowed] [numeric](30, 2) NULL,
	[copay_amount] [numeric](30, 2) NULL,
	[copay_tier_cd] [varchar](20) NULL,
	[amount_paid] [numeric](30, 2) NULL,
    drug_type [varchar](20) NULL,   
    member_last_name [varchar](50) NULL,  
    member_first_name [varchar](50) NULL,  
    member_middle_name [varchar](50) NULL,  
    birth_dt [datetime] NULL,  
    gender [varchar](50) NULL,  
    prescriber_provider_first_name [varchar](50) NULL,  
    prescriber_provider_last_name [varchar](50) NULL,  
    prescriber_provider_prov_type_cd [varchar](50) NULL,  
    pharmacy_provider_first_name [varchar](50) NULL,  
    pharmacy_provider_last_name [varchar](50) NULL,  
    pharmacy_provider_prov_type_cd [varchar](50) NULL,  
    pharmacy_provider_specialty_cd [varchar](50) NULL 
)
GO
if  exists (select * from sys.objects where object_id = object_id(N'[dbo].[claim_prop_type]') and type in (N'u'))
drop table [dbo].[claim_prop_type]
Go
CREATE TABLE [dbo].[claim_prop_type]
(
[claim_prop_type_idn] [numeric](18) not null,
[claim_prop_type] [varchar](50),
[prop_type_ref] [VARCHAR](50),
[entity_active] [char](1),
CONSTRAINT [pk_claim_prop_type] PRIMARY KEY ([claim_prop_type_idn])
)
GO
if  exists (select * from sys.objects where object_id = object_id(N'[claim_prop_type_hx]') and type in (N'u'))
drop table [dbo].[claim_prop_type_hx]
Go
CREATE TABLE [dbo].[claim_prop_type_hx]
(
[hx_idn] [numeric](18) not null identity(1, 1),
[claim_prop_type_idn] [numeric](18) null,
[claim_prop_type] [varchar](50),
[prop_type_ref] [VARCHAR](50),
[entity_active] [char](1),
[hx_crt_dt] [datetime],
CONSTRAINT pk_claim_prop_type_hx PRIMARY KEY (hx_idn)
)
GO
ALTER TABLE [dbo].[claim_prop_type_hx] ADD CONSTRAINT [df_claim_prop_type_hx_crt_dt] DEFAULT (getdate()) FOR [hx_crt_dt]
GO
CREATE TRIGGER [dbo].[th_claim_prop_type] on [dbo].[claim_prop_type]
AFTER UPDATE
AS
BEGIN TRY
   insert into claim_prop_type_hx([claim_prop_type_idn], [claim_prop_type], [prop_type_ref], [entity_active], [hx_crt_dt])
   SELECT [claim_prop_type_idn], [claim_prop_type], [prop_type_ref], [entity_active], getdate() from Deleted
 END TRY
 BEGIN CATCH
  SELECT Error_number()as Eror_Number ,error_message() as Error_message
 END CATCH
GO
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(1,'SERVICING_PRV_SPLTY_CD','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(2,'PLACE_OF_SVC_CD','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(3,'DT_CLAIM_RECEIVED','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(4,'DT_OF_SVC_BEGIN','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(5,'PRIMARY_DIAG_CODE','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(6,'ICD9_DIAG_CODE_1','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(7,'ICD9_DIAG_CODE_2','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(8,'ICD9_DIAG_CODE_3','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(9,'ICD9_DIAG_CODE_4','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(10,'TYPE_OF_BILL','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(11,'ADMIT_TYPE_CD','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(12,'PAID_AMT_TOTAL','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(13,'PROC_CD','CLAIM_MED_LINE','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(14,'REVENUE_CODE','CLAIM_MED_LINE','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(15,'DT_OF_SVC_BEG_LINE_ITEM','CLAIM_MED_LINE','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(16,'DT_OF_SVC_END_LINE_ITEM','CLAIM_MED_LINE','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(17,'SERVICING_PRV_ID','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(18,'ATTENDING_PRV_ID','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(19,'BILLING_PRV_ID','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(20,'TYPE_OF_SVC_CD','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(21,'DT_ADMITTED','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(22,'DT_DISCHARGED','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(23,'DT_OF_SVC_END','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(24,'DT_PAID','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(25,'DRG_CODE','CLAIM_MED_HEADER','Y')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(26,'CPT_HCPCS_MODIFIER','CLAIM_MED_LINE','N')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(27,'BILLED_HCPCS_MODIFIER1','CLAIM_MED_LINE','N')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(28,'BILLED_HCPCS_MODIFIER2','CLAIM_MED_LINE','N')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(29,'BILLED_HCPCS_MODIFIER3','CLAIM_MED_LINE','N')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(30,'PAID_AMT_LINE_ITEM','CLAIM_MED_LINE','N')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(31,'NDC','CLAIM_PHARMACY','N')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(32,'QTY_DISPENSED','CLAIM_PHARMACY','N')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(33,'RX_CLASS','CLAIM_PHARMACY','N')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(34,'DRUG_NAME','CLAIM_PHARMACY','N')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(35,'REFILL','CLAIM_PHARMACY','N')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(36,'AMOUNT_PAID','CLAIM_PHARMACY','N')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(37,'PRESCRIBER_PRV_IDN','CLAIM_PHARMACY','N')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(38,'NO_OF_REFILL','CLAIM_PHARMACY','N')
INSERT INTO [claim_prop_type] ([claim_prop_type_idn],[claim_prop_type],[prop_type_ref],[entity_active])VALUES(39,'DATE_FILLED','CLAIM_PHARMACY','N')
GO
if  exists (select * from sys.objects where object_id = object_id(N'[dbo].[claim_processed_detail]') and type in (N'u'))
drop table [dbo].[claim_processed_detail]
go
if  exists (select * from sys.objects where object_id = object_id(N'[dbo].[claim_processed_main]') and type in (N'u'))
drop table [dbo].[claim_processed_main]
go
IF  EXISTS (SELECT * FROM sys.partition_schemes WHERE name = N'sch_claim')
DROP PARTITION SCHEME [sch_claim]
GO
IF  EXISTS (SELECT * FROM sys.partition_functions WHERE name = N'pfn_claim')
DROP PARTITION FUNCTION [pfn_claim]
GO
CREATE PARTITION FUNCTION [pfn_claim](numeric(18,0)) AS RANGE LEFT FOR VALUES (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49)
GO
CREATE PARTITION SCHEME [sch_claim] AS PARTITION [pfn_claim] TO ([PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY], [PRIMARY])
GO
create table [dbo].[claim_processed_main](
    [claim_processed_main_idn] [numeric](18, 0) NOT NULL identity(1, 1),
	[claim_id] [varchar](50) null,
	[claim_dt] [datetime] null,
	[claim_month] [numeric](18) NOT null,
	[value_ref] [varchar](25) null,
	[mbr_idn] [numeric](18, 0) null,
    [row_idn] [numeric](18, 0) null,
    CONSTRAINT pk_claim_processed_main PRIMARY KEY nonclustered (claim_processed_main_idn, claim_month)
) on [sch_claim]([claim_month])
GO
create table [dbo].[claim_processed_detail](
    [claim_processed_detail_idn] [numeric](18, 0) not null identity(1, 1),
	[claim_id] [varchar](50) null,
	[claim_prop_type_idn] [numeric](18, 0) NOT null,
	[prop_value] [varchar](100) null,
	[row_idn] [numeric](18, 0) null,
    CONSTRAINT pk_claim_processed_detail PRIMARY KEY nonclustered (claim_processed_detail_idn, claim_prop_type_idn)
) on [sch_claim]([claim_prop_type_idn])
GO
if  exists (select * from dbo.sysobjects where id = object_id(N'[df_claim_pro_hx_cr_dt]') and type = 'd')
begin
alter table [dbo].[claim_process_track_hx] drop constraint [df_claim_pro_hx_cr_dt]
end

GO

if  exists (select * from sys.objects where object_id = object_id(N'[dbo].[claim_process_track]') and type in (N'u'))
drop table [dbo].[claim_process_track]
GO

create table [dbo].[claim_process_track](
	[processed_header_idn] [numeric](18, 0) null,
	[processed_line_idn] [numeric](18, 0) null,
	[processed_pharmacy_claim_idn] [numeric](18, 0) null,
	[process_dt] [datetime] null,
	[from_dt] [datetime] null
)

GO
if  exists (select * from sys.objects where object_id = object_id(N'[dbo].[claim_process_track_hx]') and type in (N'u'))
alter table [dbo].[claim_process_track_hx]
	ADD [processed_pharmacy_claim_id] [numeric](18, 0) null,
	    [process_dt] [datetime] null,
	    [from_dt] [datetime] null
GO
CREATE TRIGGER [dbo].[th_claim_process_track] on [dbo].[claim_process_track]
AFTER UPDATE
AS
BEGIN TRY
   insert into claim_process_track_hx([processed_header_id], [processed_line_id], [processed_pharmacy_claim_id], [process_dt], [from_dt], [hx_crt_dt])
   SELECT [processed_header_idn], [processed_line_idn], [processed_pharmacy_claim_idn], [process_dt], [from_dt], getdate() from Deleted
 END TRY
 BEGIN CATCH
  SELECT Error_number()as Eror_Number ,error_message() as Error_message
 END CATCH
GO
INSERT INTO CLAIM_PROCESS_TRACK(PROCESSED_HEADER_IDN,PROCESSED_LINE_IDN,PROCESSED_PHARMACY_CLAIM_IDN,PROCESS_DT,FROM_DT)
VALUES (0,0,0,NULL,NULL)
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[P_CLAIM_PROCESS]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[P_CLAIM_PROCESS]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UFN_MONTHLIST]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[UFN_MONTHLIST]
GO
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[V_MBR_PROCESS]'))
DROP VIEW [dbo].[V_MBR_PROCESS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[V_MBR_PROCESS]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [dbo].[V_MBR_PROCESS]
AS 
SELECT 
    MBR.MBR_IDN,
    DATEDIFF(yy,MBR.MBR_BIRTH_DT,GETDATE()) AS AGE,
    MBR.MBR_GENDER_CD,
    CASE WHEN MBR.CRT_DT > (SELECT ISNULL(PROCESS_DT, DATEADD(M,-24,GETDATE())) FROM CLAIM_PROCESS_TRACK WITH(NOLOCK)) THEN ''Y'' ELSE ''N'' END  NEW
FROM 
    MBR_CVG WITH(NOLOCK)
    JOIN MBR WITH(NOLOCK) ON (MBR_CVG.MBR_IDN = MBR.MBR_IDN)
WHERE 
    MBR_CVG.IS_PRIMARY = ''Y''
    AND (MBR.MBR_EXPIRED = ''N''
        OR MBR.MBR_EXPIRED  IS NULL)
    AND MBR.ENTITY_ACTIVE = ''Y''
    AND MBR_CVG.ENTITY_ACTIVE = ''Y'';'
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UFN_MONTHLIST]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = 
N'CREATE FUNCTION [dbo].[UFN_MONTHLIST]( @IP_VAL NUMERIC ) 
RETURNS @L_DATA TABLE(COL1 INT)
AS 
BEGIN
    --- CHECK IF INPUT IS GREATER THAN 12 THEN GIVE OUTPUT INTEGERS BETWEEN 1 AND 12.
      IF @IP_VAL >= 12  
      BEGIN 
            DECLARE @A INT
            SET @A = 1
               WHILE @A <= 12
               BEGIN
                    INSERT INTO @L_DATA (COL1)
                     SELECT @A
                     SET @A = @A + 1
                END
       END
       --- IF INPUT IS LESS THAN 12 THEN DECREASE THE CURRENT MONTH BY IP_VAL NUMBER OF TIMES
       ELSE
       BEGIN 
            SET @A = 0
               WHILE @A <= @IP_VAL
               BEGIN
                    INSERT INTO @L_DATA (COL1)
                     SELECT month(dateadd(MM, - (@A), GETDATE()))
                     SET @A = @A + 1
                END
       END
   RETURN    
END' 
END
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[P_CLAIM_PROCESS]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[P_CLAIM_PROCESS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[P_CLAIM_PROCESS]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[P_CLAIM_PROCESS]
AS
BEGIN
	set nocount on
    DECLARE @prop_type varchar(50)
    DECLARE @prop_type_ref varchar(50)
    DECLARE @nRow numeric(18)
    DECLARE @nRows numeric(18)
    DECLARE @nMon numeric(18)
    DECLARE @strQry varchar(max)
    DECLARE @Date datetime
    DECLARE @dtDate datetime
    DECLARE @nLookBack int
    DECLARE @nRowCnt numeric(18)

    set @nLookBack = 24
    
    set @dtDate = getdate()

    select @Date = isnull(PROCESS_DT, dateadd(MM, -(@nLookBack), GETDATE())) from CLAIM_PROCESS_TRACK with (nolock)

    --create table #tmp(proc_cd varchar(15))
    --insert into #tmp(proc_cd) select proc_cd from code_proc with(nolock) where proc_cd between ''80000'' and ''89999'' and len(proc_cd) = 5

    exec(''truncate table [dbo].[claim_header_stg]'')
    exec(''truncate table [dbo].[claim_line_stg]'')
    exec(''truncate table [dbo].[pharmacy_claim_stg]'')

    PRINT ''DELETING OLD DATA...''
    DELETE FROM CLAIM_PROCESSED_DETAIL WHERE CLAIM_ID IN (SELECT CLAIM_ID FROM CLAIM_PROCESSED_MAIN WHERE CLAIM_DT < DATEADD(M,-(@nLookBack),GETDATE()));
    DELETE FROM CLAIM_PROCESSED_MAIN WHERE CLAIM_DT < DATEADD(M,-(@nLookBack),GETDATE());

    PRINT ''Populating claim header to the staging table''
    set @dtDate = getdate()
    insert into [dbo].[claim_header_stg]
        (DT_CLAIM_RECEIVED, CLAIM_MONTH, CLAIM_ID, ENROLL_ID, MBR_IDN, ADMIT_TYPE_CD, SERVICING_PRV_ID, SERVICING_PRV_SPLTY_CD,
		SERVICING_PRV_PAR, ATTENDING_PRV_ID, BILLING_PRV_ID, PLACE_OF_SVC_CD, TYPE_OF_SVC_CD, TYPE_OF_BILL, GROUP_NO, CLAIM_TYPE, 
		ALLOWED_AMT_TOTAL, BILLED_AMT_TOTAL, PAID_AMT_TOTAL, DT_ADMITTED, DT_DISCHARGED, DT_OF_SVC_BEGIN, DT_OF_SVC_END, 
		DRG_CODE, PRIMARY_DIAG_CODE, ICD9_DIAG_CODE_1, ICD9_DIAG_CODE_2, ICD9_DIAG_CODE_3, ICD9_DIAG_CODE_4, DT_PAID)
    select
        mcvh.date_claim_received, month(mcvh.date_of_service_begin), convert(varchar(25),mcvh.claim_id), mcvh.enroll_id, mi.mbr_idn, convert(varchar(25),mcvh.admit_type_cd), mcvh.servicing_provider_id, mcvh.servicing_prov_specialty_cd,
        mcvh.servicing_provider_par, convert(varchar(25),mcvh.attending_provider_id), mcvh.billing_provider_id, convert(varchar(25),mcvh.place_of_service_cd), convert(varchar(25),mcvh.type_of_service_cd), mcvh.type_of_bill, mcvh.group_no, mcvh.claim_type, 
        convert(Numeric(18,2),mcvh.allowed_amt_total), convert(Numeric(18,2),mcvh.billed_amt_total), convert(Numeric(18,2),mcvh.paid_amt_total), mcvh.date_admitted, mcvh.date_discharged, mcvh.date_of_service_begin, mcvh.date_of_service_end, 
        mcvh.drg_cd, convert(varchar(20),mcvh.primary_diagnosis_cd), mcvh.icd9_diagnosis_code_1, mcvh.icd9_diagnosis_code_2, mcvh.icd9_diagnosis_code_3, convert(varchar(20),mcvh.icd9_diagnosis_code_4), mcvh.date_paid
    from
        prodedw2.datawarehouseisproduction.dbo.bci_medical_claims_view_header mcvh with(nolock)
        inner join mbr_identfn mi with(nolock) on mi.identfd_number = mcvh.enroll_id
        INNER JOIN V_MBR_PROCESS MB ON MB.MBR_IDN = mi.MBR_IDN
        and mi.identfd_type = ''ALT''
    WHERE
        (mcvh.date_of_service_begin > @Date OR MB.NEW =''Y'')
        AND (convert(varchar(25),mcvh.place_of_service_cd) <> ''81''
            AND convert(varchar(25),mcvh.claim_id) IN 
                (SELECT CLAIM_ID FROM prodedw2.datawarehouseisproduction.dbo.bci_medical_claims_view_line mcvl with(nolock)
                WHERE 
                    (procedure_cd NOT BETWEEN ''80000'' AND ''89999''
                    AND procedure_cd NOT IN (''36400'', ''36405'', ''36406'', ''36410'', ''36415'',''36416'', ''36420'', ''36425''))
                    OR procedure_cd IS NULL)
            )
      AND mi.MBR_IDN IS NOT NULL
      AND mcvh.date_of_service_begin > DATEADD(M,-(@nLookBack),GETDATE())

    print convert(varchar,@@rowcount) + '' Row(s)''
    print convert(varchar,datediff(ss, @dtDate, getdate())) + '' Sec(s)''

    set @dtDate = getdate()

    PRINT ''Populating claim line to the staging table''
    insert into [dbo].[claim_line_stg]
        (mbr_idn, claim_id, claim_suffix, line_number, auth_id, proc_cd, proc_desc, revenue_code, 
        cpt_hcpcs_modifier, billed_hcpcs_modifier1, billed_hcpcs_modifier2, billed_hcpcs_modifier3, 
        allowed_amt_line_item, billed_amt_line_item, cob_paid_amt_line_item, coinsurance_amt_line_item, 
        copay_amt_line_item, deductible_amt_line_item, not_covered_amt_line_item, paid_amt_line_item, 
        dt_of_svc_beg_line_item, dt_of_svc_end_line_item, units_per_days_allowed, units_per_days_billed, 
        claim_status_code_line_item, anesthesia_start_time, anesthesia_end_time, anesthesia_total_time, 
        err_code, err_code_text, member_full_name, birth_dt, gender, group_name, group_effective_date, 
        group_term_date, servicing_provider_first_name, servicing_provider_last_name, servicing_provider_prov_type_cd, 
        attending_provider_first_name, attending_provider_last_name, attending_provider_prov_type_cd, 
        attending_provider_specialty_cd, billing_provider_first_name, billing_provider_last_name)
    select
        [claim_header_stg].mbr_idn, mcvl.claim_id, mcvl.claim_suffix, mcvl.line_number, mcvl.auth_id, mcvl.procedure_cd, mcvl.procedure_desc, mcvl.revenue_cd,
        convert(varchar(25),mcvl.cpt_hcpcs_modifier), convert(varchar(25),mcvl.billled_hcpcs_modifier1), convert(varchar(25),mcvl.billled_hcpcs_modifier2),
        convert(varchar(25),mcvl.billled_hcpcs_modifier3), mcvl.allowed_amt_line_item, mcvl.billed_amt_line_item, mcvl.cob_paid_amt_line_item,
        mcvl.coinsurance_amt_line_item, mcvl.copay_amt_line_item, mcvl.deductible_amt_line_item, mcvl.not_covered_amt_line_item, mcvl.paid_amt_line_item,
        convert(datetime,mcvl.date_of_service_beg_line_item), convert(datetime,mcvl.date_of_service_end_line_item), mcvl.units_per_days_allowed,
        mcvl.units_per_days_billed, mcvl.claim_status_code_line_item, mcvl.anesthesia_start_time, mcvl.anesthesia_end_time, mcvl.anesthesia_total_time,
        mcvl.error_cd err_code, mcvl.error_code_text err_code_text, mcvl.member_full_name, mcvl.birth_dt, mcvl.gender, mcvl.group_name,
        mcvl.group_effective_date, mcvl.group_term_date, convert(varchar(32),mcvl.servicing_provider_first_name), mcvl.servicing_provider_last_name,
        mcvl.servicing_provider_prov_type_cd, mcvl.attending_provider_first_name, mcvl.attending_provider_last_name, mcvl.attending_provider_prov_type_cd,
        mcvl.attending_provider_specialty_cd, mcvl.billing_provider_first_name, convert(varchar(32),mcvl.billing_provider_last_name)
    from
        prodedw2.datawarehouseisproduction.dbo.bci_medical_claims_view_line mcvl with(nolock)
        inner join [claim_header_stg] with(nolock) on mcvl.claim_id = [claim_header_stg].claim_id
    WHERE 
        (mcvl.procedure_cd NOT BETWEEN ''80000'' AND ''89999''
        AND mcvl.procedure_cd NOT IN (''36400'', ''36405'', ''36406'', ''36410'', ''36415'',''36416'', ''36420'', ''36425''))
        OR mcvl.procedure_cd IS NULL
                    
    print convert(varchar,@@rowcount) + '' Row(s)''
    print convert(varchar,datediff(ss, @dtDate, getdate())) + '' Sec(s)''

    /*
    set @dtDate = getdate()

    PRINT ''Populating pharmacy claim to the staging table''
    insert into [dbo].[pharmacy_claim_stg]
        (enroll_id, claim_id, mbr_idn, prescriber_prv_idn, prescriber_name, date_filled, ndc, pharmacy_prv_idn, 
        prv_dea_num, pharmacy_nabp_num, dispense_status_code, qty_dispensed, days_supply, rx_class, drug_name, 
        refill, route, amount_billed, amount_allowed, copay_amount, copay_tier_cd, amount_paid, drug_type, 
        member_last_name, member_first_name, member_middle_name, birth_dt, gender, prescriber_provider_first_name, 
        prescriber_provider_last_name, prescriber_provider_prov_type_cd, pharmacy_provider_first_name, 
        pharmacy_provider_last_name, pharmacy_provider_prov_type_cd, pharmacy_provider_specialty_cd)
    select   
        pcv.enroll_id, convert(varchar(50),pcv.claim_id), mi.mbr_idn, pcv.prescriber_prv_id, pcv.prescriber_name,
        pcv.date_filled, convert(varchar(50),pcv.ndc), convert(numeric(18,2),pcv.pharmacy_prv_id), pcv.provider_dea_num,
        convert(varchar(50),pcv.pharmacy_nabp_num), convert(varchar(50),pcv.dispense_status_code), pcv.qty_dispensed,   
        pcv.days_supply, convert(varchar(50),pcv.rx_class), pcv.drug_name, pcv.refill, pcv.route, convert(numeric(18,2),pcv.amount_billed),
        convert(numeric(18,2),pcv.amount_allowed), convert(numeric(18,2),pcv.copay_amount), convert(varchar(50),pcv.copay_tier_cd),
        convert(numeric(18,2),pcv.amount_paid), pcv.drug_type, pcv.member_last_name, pcv.member_first_name, pcv.member_middle_name,  
        convert(Datetime,pcv.birth_dt), pcv.gender, pcv.prescriber_provider_first_name, pcv.prescriber_provider_last_name, pcv.prescriber_provider_prov_type_cd,
        pcv.pharmacy_provider_first_name, pcv.pharmacy_provider_last_name, convert(varchar(50),pcv.pharmacy_provider_prov_type_cd), pcv.pharmacy_provider_specialty_cd  
    from
        prodedw2.datawarehouseisproduction.dbo.bci_pharmacy_claims_view pcv with(nolock)
        left outer join mbr_identfn mi with(nolock) on mi.identfd_number = pcv.enroll_id
        INNER JOIN V_MBR_PROCESS V_MBR with(nolock) ON V_MBR.MBR_IDN = mi.MBR_IDN
    WHERE
        (DATE_FILLED > @Date OR V_MBR.NEW =''Y'')
        AND DATE_FILLED > DATEADD(M,-(@nLookBack),GETDATE())

    print convert(varchar,@@rowcount) + '' Row(s)''
    print convert(varchar,datediff(ss, @dtDate, getdate())) + '' Sec(s)''

    */

    set @nMon = 1

    WHILE @nMon <= 12
    Begin
        set @dtDate = getdate()
        Print ''Header Main: Month -  '' + convert(varchar, @nMon)
        INSERT INTO CLAIM_PROCESSED_MAIN(CLAIM_DT,CLAIM_ID,VALUE_REF,MBR_IDN,CLAIM_MONTH)
        SELECT DT_OF_SVC_BEGIN,CLAIM_ID,''CLAIM_MED_HEADER'', MBR_IDN ,CLAIM_MONTH
        FROM [claim_header_stg] WITH(NOLOCK)
        WHERE MONTH(DT_OF_SVC_BEGIN) = @nMon
        
		print convert(varchar,@@rowcount) + '' Row(s)''
		print convert(varchar,datediff(ss, @dtDate, getdate())) + '' Sec(s)''

        set @dtDate = getdate()
        
        Print ''Line Main: Month -  '' + convert(varchar, @nMon)
        INSERT INTO CLAIM_PROCESSED_MAIN(CLAIM_DT,CLAIM_ID,VALUE_REF,MBR_IDN,CLAIM_MONTH)
        SELECT dt_of_svc_beg_line_item,CLAIM_ID,''CLAIM_MED_LINE'', MBR_IDN ,MONTH(dt_of_svc_beg_line_item)
        FROM [claim_line_stg] WITH(NOLOCK)
        WHERE MONTH(dt_of_svc_beg_line_item) = @nMon
        
		print convert(varchar,@@rowcount) + '' Row(s)''
		print convert(varchar,datediff(ss, @dtDate, getdate())) + '' Sec(s)''

    /*
        Print ''Pharmacy Main: Month -  '' + convert(varchar, @nMon)
        INSERT INTO CLAIM_PROCESSED_MAIN(CLAIM_DT,CLAIM_ID,VALUE_REF,MBR_IDN,CLAIM_MONTH)
        SELECT DATE_FILLED,CLAIM_ID,''CLAIM_PHARMACY'' ,MBR_IDN,MONTH(DATE_FILLED)
        FROM [pharmacy_claim_stg] WITH(NOLOCK)
        WHERE MONTH(DATE_FILLED) = @nMon
        
		print convert(varchar,@@rowcount) + '' Row(s)''
		print convert(varchar,datediff(ss, @dtDate, getdate())) + '' Sec(s)''
    */
        set @nMon = @nMon + 1
    End

    set @nRow = 0
    set @nRows = 0

    select @nRow = min(claim_prop_type_idn), @nRows = max(claim_prop_type_idn) from claim_prop_type with(nolock) where entity_active = ''Y''
    while @nRow <= @nRows
    begin

        IF EXISTS(select * from claim_prop_type with(nolock) where entity_active = ''Y'' and claim_prop_type_idn = @nRow)
        Begin

            select @prop_type = claim_prop_type, @prop_type_ref = prop_type_ref from claim_prop_type with(nolock) where entity_active = ''Y'' and claim_prop_type_idn = @nRow
            PRINT ''INSERTING DATA FOR '' + @prop_type + ''...''
            set @dtDate = getdate()

			set @nRowCnt = 0

            set @nMon = 1

            WHILE @nMon <= 12
            Begin
                if @prop_type_ref = ''CLAIM_MED_HEADER''
                    set @strQry = ''INSERT INTO CLAIM_PROCESSED_DETAIL(CLAIM_ID,CLAIM_PROP_TYPE_IDN,PROP_VALUE)
                                    SELECT CLAIM_ID,''+ convert(varchar,@nRow) +'',''+ @prop_type +'' FROM [claim_header_stg] WITH(NOLOCK)
                                    WHERE LEN(ISNULL(CONVERT(VARCHAR(100),''+ @prop_type +''), '''''''')) > 0 AND MONTH(DT_OF_SVC_BEGIN) = ''+ convert(varchar,@nMon)
                else
                    if @prop_type_ref = ''CLAIM_MED_LINE''
                        set @strQry = ''INSERT INTO CLAIM_PROCESSED_DETAIL(CLAIM_ID,CLAIM_PROP_TYPE_IDN,PROP_VALUE)
                            SELECT CLAIM_ID,''+ convert(varchar,@nRow) +'',''+ @prop_type +'' FROM [claim_line_stg] WITH(NOLOCK)
                            WHERE LEN(ISNULL(CONVERT(VARCHAR(100),''+ @prop_type +''), '''''''')) > 0 AND MONTH(dt_of_svc_beg_line_item) = ''+ convert(varchar,@nMon)
                    else
                        set @strQry = ''INSERT INTO CLAIM_PROCESSED_DETAIL(CLAIM_ID,CLAIM_PROP_TYPE_IDN,PROP_VALUE)
                            SELECT CLAIM_ID,''+ convert(varchar,@nRow) +'',''+ @prop_type +'' FROM PHARMACY_CLAIM WITH(NOLOCK)
                            WHERE LEN(ISNULL(CONVERT(VARCHAR(100),''+ @prop_type +''), '''''''')) > 0 AND MONTH(DATE_FILLED) = ''+ convert(varchar,@nMon)

                
                exec(@strQry)
                set @nRowCnt = @nRowCnt + @@rowcount
                set @nMon = @nMon + 1
            End
			print convert(varchar,@nRowCnt) + '' Row(s)''
			print convert(varchar,datediff(ss, @dtDate, getdate())) + '' Sec(s)''
        End
        set @nRow = @nRow + 1
    end

    UPDATE 
        CLAIM_PROCESS_TRACK 
    SET 
        PROCESS_DT = (SELECT max(claim_dt) FROM CLAIM_processed_main with(nolock)),
        FROM_DT=(SELECT min(claim_dt) FROM CLAIM_processed_main with(nolock))

    PRINT ''PROCEDURE EXECUTION COMPLETED''
END' 
END
GO
INSERT INTO [code_sre_event_name] ([name],[entity_active],[crt_dt],[upd_dt],[user_idn],[is_default],[is_required],[source])VALUES('DM Asthma','Y',getdate(),getdate(),2,'N','N','Manual')
INSERT INTO [code_sre_event_name] ([name],[entity_active],[crt_dt],[upd_dt],[user_idn],[is_default],[is_required],[source])VALUES('DM Asthma Ruleset','Y',getdate(),getdate(),2,'N','N','Manual')
GO
INSERT  INTO [versioning] ([Version_Number], [Version_Dt], [V_Comment], [crt_dt], [upd_dt], [user_idn])
VALUES  ('5.2_BCI_092', GETDATE(), 'Script to create objects related to DMID claim processing', GETDATE(), GETDATE(), 2)
PRINT 'Script with version_number 5.2_BCI_092 executed Successfully'

