set nocount on
GO
ALTER VIEW [dbo].[V_MBR_PROCESS]
AS 
SELECT 
    MBR.MBR_IDN,
    FLOOR(DATEDIFF(DD,MBR.MBR_BIRTH_DT,GETDATE())/365.0) AS AGE,
    MBR.MBR_GENDER_CD,
    CASE WHEN MBR.CRT_DT > (SELECT ISNULL(PROCESS_DT, DATEADD(M,-24,GETDATE())) FROM CLAIM_PROCESS_TRACK WITH(NOLOCK)) THEN 'Y' ELSE 'N' END  NEW
FROM 
    MBR_CVG WITH(NOLOCK)
    JOIN MBR WITH(NOLOCK) ON (MBR_CVG.MBR_IDN = MBR.MBR_IDN)
WHERE 
    MBR_CVG.IS_PRIMARY = 'Y'
    AND (MBR.MBR_EXPIRED = 'N'
        OR MBR.MBR_EXPIRED  IS NULL)
    AND MBR.ENTITY_ACTIVE = 'Y'
    AND MBR_CVG.ENTITY_ACTIVE = 'Y';
GO
INSERT  INTO [versioning] ([Version_Number], [Version_Dt], [V_Comment], [crt_dt], [upd_dt], [user_idn])
VALUES  ('5.2_BCI_099', GETDATE(), 'Script for modifying the age calculation for mbr process view', GETDATE(), GETDATE(), 2)
PRINT 'Script with version_number 5.2_BCI_099 executed Successfully'
